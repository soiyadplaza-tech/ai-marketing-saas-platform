# FOYSAL IT — Production Deploy to Vercel (Enterprise)

This project is **Vercel-ready**. The config (`vercel.json`) already sets:
- **Region:** `bom1` (Mumbai, low latency for BD/South Asia)
- **Enterprise security headers:** HSTS, CSP, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy
- **Vercel Cron:** the AI autopilot runs **daily at 09:00 UTC** at `/api/cron/autopilot`

Database = your **permanent Neon PostgreSQL** (Pooler URL, connection-pooled for serverless).
Schema **self-syncs** automatically at runtime (`ensureSchema` bootstrap) — no manual migrations needed on every deploy.

## Step 1 — Push to GitHub
```
git init
git add .
git commit -m "FOYSAL IT production"
git remote add origin https://github.com/YOUR_USER/foysal-it-app.git
git push -u origin main
```

## Step 2 — Import into Vercel
1. Go to **https://vercel.com/new** (log in with the account that owns foysalit.com).
2. Select the repo → **Deploy**. Framework **Next.js** auto-detects.

## Step 3 — Add these Environment Variables
Vercel → Project → **Settings → Environment Variables** (add for Production + Preview):

| Variable | Value |
|---|---|
| `APP_DATABASE_URL` | `postgresql://neondb_owner:npg_lnwr7iI5qMXW@ep-noisy-hat-ayc6kmdh-pooler.c-5.us-east-2.aws.neon.tech/neondb?sslmode=require&channel_binding=require` |
| `GMAIL_USER` | `foysalahmed.dm23@gmail.com` |
| `GMAIL_APP_PASSWORD` | `vgyzgzygkmekwkll` (16 chars, no spaces) |
| `RESEND_API_KEY` | `re_MYApY4fz_5SJhad2ttbSracdYpnjQieDU` |
| `BASE44_APP_ID` | `6a849b83405883d52562ab27` |
| `BASE44_API_KEY` | `140fb9b3c3454a9183655ebfd8e125a8` |
| `SHEET_IMPORT_URL` | `https://docs.google.com/spreadsheets/d/1I14GPL_LLCvSUyHT8aU2xDSJAXLxIDuUFweSDUrqWLA/edit?pli=1&gid=1267128335#gid=1267128335` |
| `APP_BASE_URL` | `https://foysalit.com` |
| `CRON_SECRET` | any long random string (secures the daily autopilot cron) |

> The database client reads `APP_DATABASE_URL` first (your persistent Neon), so the
> app is never tied to a temporary environment database.

## Step 4 — Add the domain
Vercel → Project → **Settings → Domains** → add `foysalit.com` (+ `www.foysalit.com`).
Your nameservers are already on Vercel (`echo/pulse.balancedserver.com`), so it verifies
**instantly** and a free SSL certificate is issued.

## Step 5 — Verify (production self-heal + status)
Open in your browser:
- **https://foysalit.com** — first visit auto-creates tables + imports the 45k+ leads.
- **https://foysalit.com/api/deploy/ensure** — returns a JSON health report:
  `{"ok":true,"ready":true,"db":"neon-postgres","leads":45612,...}`
- **https://foysalit.com/api/health** — `{"ok":true,"schema":"ready"}`

## Daily AI autopilot (unattended)
The `vercel.json` **cron** fires `/api/cron/autopilot` **every day at 09:00 UTC**.
It is protected by `CRON_SECRET` (Vercel sends `Authorization: Bearer <CRON_SECRET>`).
Pipeline: audit fresh leads → score → match service → write personalized email →
auto-approve a small batch → send via Gmail (backup Resend/SendGrid), capped at
400–1500/day, opt-out list respected.

## Why no build-time migration?
Vercel builds are stateless and shouldn't touch the DB. Instead the app uses a
**self-healing `ensureSchema` bootstrap** that syncs the schema on the first
request after deploy — drift-free, zero manual steps, and verifiable via
`/api/deploy/ensure`. This is the recommended pattern for serverless + Postgres.

## Your permanent live URL
**https://foysalit.com**  (+ cron: `https://foysalit.com/api/cron/autopilot`)
